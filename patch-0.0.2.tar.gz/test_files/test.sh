# Color variables
red='\033[0;31m'
green='\033[0;32m'
yellow='\033[0;33m'
blue='\033[0;34m'
magenta='\033[0;35m'
cyan='\033[0;36m'
clear='\033[0m'

packages="mosquitto net-tools ifupdown libboost-program-options-dev libssl-dev make gcc hostapd dnsmasq"
services="hostapd dnsmasq mosquitto leaps-server docker" #maybe docker
file_exists="/etc/default/grub /etc/netplan/01-network-manager-all.yaml /etc/network/interfaces /etc/hostapd/hostapd.conf /etc/default/hostapd /etc/dnsmasq.conf /lib/systemd/system/dnsmasq.service /etc/init.d/leaps-server /etc/mosquitto/conf.d/mosquitto.conf"

# Version
patch="0.0.2"


logo(){
    echo -e "---------------------------------"
    echo -e ${blue}
    echo -e "    ____   __  __   "
    echo -e "   / __ \ / / / /   "
    echo -e "  / / / // /_/ /    "
    echo -e " / /_/ // __  /     "
    echo -e "/_____//_/ /_/      "
    echo -e ${clear}
    echo -e "Drive Hockey Analytics"
    echo -e "Version: ${patch}"

}

# Print a message with a green checkmark
success(){
    echo -e "  ${green} ✔ ${clear}$1"
}

# Print a message with a red cross
error(){
    echo -e "  ${red} ✖ ${clear}$1"
}

step(){
    echo -e "  ${yellow} ► ${clear}$1"
}

task(){
    echo -e "${blue} ● ${clear}$1"
}

clear_last_line(){
    tput cuu 1 && tput el
}



check_service_running(){
    task "Checking Services"
    for service in $@; do
        if [ "$(systemctl show -p ActiveState --value $service)" != "active" ]; then
            error "$service is not running"
        else
            success "$service"
        fi
    done
    # systemctl show -p ActiveState --value $1
    # systemctl show -p SubState --value $1
}



check_permission_of_file(){
    task "Checking File Permissions"
    for file in $1/*; do
        if [ "$(stat -L -c "%a" $file)" != "755" ]; then
            error "$file permissions are not correct"
        else
            success "$file"
        fi
    done

    
}

# Install a package
install_package(){
    if ! apt install $1 -y >/dev/null 2>&1; then
        echo -n "   "
        error "Failed to install $1"
    else
        echo -n "   "
        success "Installed $1"
    fi
}

# Check if packages are installed, if not install them
check_packages(){
    task "Checking Packages"
    for package in $@; do
        if ! dpkg -s $package >/dev/null 2>&1; then
            error "$package is not installed"
            install_package $package
        else
            success "$package"
        fi
    done
}


check_docker_containers(){
    task "Checking Docker Containers"
    #Get a list of all containers and set as a local variable
    containers=$(docker ps -a --format "{{.Names}}")
    #Check if the container is running
    for container in $containers; do
        if [ "$(docker inspect -f '{{.State.Running}}' $container)" == "true" ]; then
            success "$container"
        else
            error "$container is not running"
        fi
    done

}

check_files(){
    task "Checking Files Structure"
    for file in $@; do
        local file_name=$(basename $file)
        if ! diff -u $file ./test_files/$file_name >/dev/null 2>&1; then
            diff -u $file ./test_files/$file_name >> /var/log/drivehockey.log
            error "$file does not match"
        else
            success "$file"
        fi
    done
}

# Make a list of files and check if they exist
check_file_exists(){
    task "Checking Files"
    for file in $@; do
        if [ -f $file ]; then
            success "$file"
        else
            error "$file does not exist"
        fi
    done
}

check_word_in_file(){
    task "Checking File"
    if grep -q $1 $2; then
        success "$2"
    else
        error "$2 does not contain $1"
    fi
}

#function that replaces specific password= line in file
replace_password_in_file(){
    task "Replacing Password in File"
    sed -i "s/password=.*/password=$1/g" $2
    if grep -q $1 $2; then
        success "$2"
    else
        error "$2 does not contain $1"
    fi
}




troubleshoot(){
    # List of packages to be run in the check_packages function
    check_packages $packages

    # List of services to be run in the check_service_running function
    check_service_running $services

    check_docker_containers

    check_file_exists $file_exists
    # for all files in the /data directory check_permission_of_file
    check_permission_of_file /data/leaps

    #compare files in the file directory to the files on the system
    check_files $file_exists

}



patch_system(){
    step "Applying Patch 0.0.2"
    # Add Domain name to dnsmasq
    task "Configuring track.drivehockey.com DNS"
    cp -R ./test_files/dnsmasq.conf /etc/dnsmasq.conf
    if grep -q 'track.drivehockey.com' /etc/hosts; then
        success "$2"
    else
        error "$2 does not contain $1"
        sed "/$HOSTNAME/a 192.168.4.1   track.drivehockey.com" /etc/hosts | tee /etc/hosts.tmp
        mv -f /etc/hosts.tmp /etc/hosts
    fi
    systemctl restart dnsmasq





    task "Configuring Mosquitto with Security Credentials"
    # Config Mosquitto Password
    touch /etc/mosquitto/conf.d/passwd
    mosquitto_passwd -b /etc/mosquitto/conf.d/passwd dwmuser dwmpass
    cp -R ./test_files/mosquitto.conf /etc/mosquitto/conf.d/mosquitto.conf
    systemctl restart mosquitto
    systemctl restart leaps-server
}







#######################################
# Main
#######################################
logo
while true
do
    echo -e "---------------------------------" 
    echo -e "1. Troubleshoot"
    echo -e "2. Patch System"
    echo -e "3. Exit"
    read -p "Enter your choice: " choice
    case $choice in
        1) troubleshoot ;;
        2) patch_system ;;
        3) exit 0 ;;
        *) echo -e "${red}This Option Does Not Exist...${clear}"
    esac
done

